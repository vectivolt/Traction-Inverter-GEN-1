/*
    Copyright 2017 Benjamin Vedder	benjamin@vedder.se

    This file is part of VESC Tool.

    VESC Tool is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    VESC Tool is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */

#ifndef FWHELPER_H
#define FWHELPER_H

#include <QObject>
#include <QVariantMap>
#include "vescinterface.h"

class FwHelper : public QObject
{
    Q_OBJECT
public:
    explicit FwHelper(QObject *parent = nullptr);
    Q_INVOKABLE QVariantMap getHardwares(FW_RX_PARAMS params, QString hw = "");
    Q_INVOKABLE QVariantMap getFirmwares(QString hw);
    Q_INVOKABLE QVariantMap getBootloaders(FW_RX_PARAMS params, QString hw);
    Q_INVOKABLE bool uploadFirmwareV2(QString filename, VescInterface *vesc,
                                    bool isBootloader, bool checkName, bool fwdCan, bool autoDisconnect);
    Q_INVOKABLE bool uploadFirmware(QString filename, VescInterface *vesc,
                                    bool isBootloader, bool checkName, bool fwdCan);
    Q_INVOKABLE bool uploadFirmwareSingleShotTimer(QString filename, VescInterface *vesc,
                                                 bool isBootloader, bool isIncluded, bool fwdCan, QString BLfilename);
    Q_INVOKABLE QVariantMap getArchiveDirs();
    Q_INVOKABLE QVariantMap getArchiveFirmwares(QString fwPath, FW_RX_PARAMS params);
    Q_INVOKABLE void reloadLatest();
    Q_INVOKABLE QString fwDlText(VescInterface *vesc);

signals:
    void fwUploadRes(bool res, bool isBootloader);

public slots:

private:
    enum FwDlStatus {
        FwDlNotDownloaded = 0,
        FwDlNotFound,
        FwDlFound
    };

    FwDlStatus mFwDlStatus;

};

#endif // FWHELPER_H
